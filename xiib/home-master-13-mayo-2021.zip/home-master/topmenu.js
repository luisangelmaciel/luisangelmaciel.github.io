function openNav() {
  document.getElementById("mySidenavmenu").style.width = "250px";
  document.getElementById("mainmenu").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidenavmenu").style.width = "0";
  document.getElementById("mainmenu").style.marginLeft= "0";
}