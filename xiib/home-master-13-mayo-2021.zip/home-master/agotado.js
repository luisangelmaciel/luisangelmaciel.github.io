// Overlay agotado


function onagotado() {
    document.getElementById("overlayagotado").style.display = "block";
}

function offagotado() {
    document.getElementById("overlayagotado").style.display = "none";
}