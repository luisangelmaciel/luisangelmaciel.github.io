document.addEventListener('DOMContentLoaded', function(){
  Code.photoSwipe('a', '#Gallery', { captionAndToolbarHideOnSwipe: false } );
}, false);

/* OTHER GALLERIES
http://codegeekz.com/jquery-image-gallery-plugins/
http://www.outsidethebracket.com/responsive-web-design-fluid-background-images/
http://osvaldas.info/
http://osvaldas.info/responsive-jquery-masonry-or-pinterest-style-layout
*/